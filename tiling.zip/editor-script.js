var block = "";
var orientation = "north";
var orient_block_types = ["piston", "piston-ext", "piston-head", "s-piston", "s-piston-ext", "s-piston-head", "tnt", "observer", "observer side", "torch", "torch-top", "redstone-t", "redstone-t-top"];

function makeTables(height, width, depth) {
	document.getElementById("form").remove();
	row = "<tr>"+"<td onclick=\"paint(this);\">".repeat(width)+"</tr>";
	myTable  = "<table>"+row.repeat(height)+"</table>";
	for(i = 0; i < depth; i++) {
		document.getElementById("tables").innerHTML += "<h2>Layer "+i+"</h2>"+myTable;
	} 
}

function chooseBlock(tile, blockType) {
	block = blockType;
	document.getElementById("block-palette").getElementsByClassName("selected")[0].classList.remove("selected");
	tile.classList.add("selected");
}

function chooseOrient(tile, orient) {
	orientation = orient;
	document.getElementById("orient-palette").getElementsByClassName("selected")[0].classList.remove("selected");
	tile.classList.add("selected");
}

function paint(tile) {
	if(orient_block_types.includes(block)) {
		tile.className = block+" "+orientation;
	}
	else {
		tile.className = block;
	}
}

function setTitle(title_str) {
	if(title_str.length == 0) {
		document.title = "MC Layer Tiling";
	}
	else {
		document.title = title_str;
	}
}